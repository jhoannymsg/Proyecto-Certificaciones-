using Domain.Models;
using Microsoft.EntityFrameworkCore;
using repository.Interfaces;
using repository.Repositories;
using Services.Interfaces;
using Services.Services;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("ProyectoPasantia");

builder.Services.AddDbContext<CourseCertificateContext>(options =>
    options.UseSqlServer(connectionString));

// Add services to the container.

builder.Services.AddControllers();

builder.Services.AddScoped<ICoursesRepository, CoursesRepository>();
builder.Services.AddTransient<ICoursesServices, CoursesService>();

builder.Services.AddScoped<IParticipantsCoursesRepository, ParticipantsCoursesRepository>();
builder.Services.AddTransient<IParticipantsCoursesService, ParticipantsCoursesService>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();




var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

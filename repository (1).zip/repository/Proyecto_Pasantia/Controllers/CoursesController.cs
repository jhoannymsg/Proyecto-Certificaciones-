﻿using Microsoft.AspNetCore.Mvc;
using Services.DTO;
using Services.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Proyecto_Pasantia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoursesController : ControllerBase
    {
        private readonly ICoursesServices _services;
        public CoursesController(ICoursesServices service)
        {
            _services = service;
        }

        // GET: api/<CoursesController>
        [HttpGet("ObtenerTodos")]
        public async Task<List<CoursesDTO>> GetAll()
        {
            return await _services.GetAll();
        }

        [HttpPost("EstoyHarta")]
        public async Task<string> Harta([FromBody] CourseSaveDto courseSaveDto)
        {
            return await _services.Harta(courseSaveDto);
        }

        [HttpGet("GetById")]
        public async Task<CoursesDTO> GetById(int id)
        {
            return await _services.GetById(id);
        }

        [HttpGet("GetByStatus")]
        public async Task<CoursesDTO> GetByStatus(int status)
        {
            return await _services.GetByStatus(status);
        }

        [HttpGet("GetByIdentify")]
        public async Task<List<CoursesDTO>> GetByIdentify(string identify)
        {
        return await _services.GetByIdentify(identify);
        }
}
}

﻿using Microsoft.AspNetCore.Mvc;
using Services.DTO;
using Services.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Proyecto_Pasantia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParticipantsCoursesController : ControllerBase
    {
        private readonly IParticipantsCoursesService _service;

        public ParticipantsCoursesController(IParticipantsCoursesService service)
        {
            _service = service;
        }

        // GET: api/<ParticipantsCoursesController>
        [HttpPost("Save")]
        public async Task<string> Save(ParticipantsCoursesSaveDto dto)
        {
            return await _service.Save(dto);
        }

    }
}

﻿using Domain.Models;
using repository.Interfaces;
using Services.DTO;
using Services.Interfaces;

namespace Services.Services
{
    public class CoursesService : ICoursesServices
    {
        private readonly ICoursesRepository _repository;
        public CoursesService(ICoursesRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<CoursesDTO>> GetAll()
        {

            var courses = await _repository.Getall();
            return courses.Select(x => new CoursesDTO
            {
                Id = x.Id,
                Name = x.Name,
                Description = x.Description,
                Durations = x.Durations,
                DurationTypeId = x.DurationTypeId,
                StatusId = x.StatusId,

            }).ToList();
        }

        public async Task<CoursesDTO> GetById(int id)
        {
            CoursesDTO coursesDTO = new CoursesDTO();
            var course = await _repository.GetById(id);

            coursesDTO.Id = course.Id;
            coursesDTO.Name = course.Name;
            coursesDTO.Description = course.Description;
            coursesDTO.Durations = course.Durations;
            coursesDTO.DurationTypeId = course.DurationTypeId;
            coursesDTO.StatusId = course.StatusId;

            return coursesDTO;

        }

        public async Task<List<CoursesDTO>> GetByIdentify(string identify)
        {
            var courses = await _repository.GetByIdentify(identify);
            return courses.Select(x => new CoursesDTO
            {
                Id = x.Id,
                Name = x.Name,
                Description = x.Description,
                Durations = x.Durations,
                DurationTypeId = x.DurationTypeId,
                StatusId = x.StatusId,

            }).ToList();
        }

        public async Task<CoursesDTO> GetByStatus(int status)
        {
            CoursesDTO coursesDTO = new CoursesDTO();
            var course = await _repository.GetByStatus(status);

            coursesDTO.Id = course.Id;
            coursesDTO.Name = course.Name;
            coursesDTO.Description = course.Description;
            coursesDTO.Durations = course.Durations;
            coursesDTO.DurationTypeId = course.DurationTypeId;
            coursesDTO.StatusId = course.StatusId;

            return coursesDTO;

        }

        public async Task<string> Harta(CourseSaveDto courseSaveDto)
        {
            Courses courses = new Courses();

            courses.Description = courseSaveDto.Description;
            courses.Durations = courseSaveDto.Durations;
            courses.CreateDate = DateTime.Now;
            courses.Name = courseSaveDto.Name;
            courses.StatusId = courseSaveDto.StatusId;
            courses.DurationTypeId = courseSaveDto.DurationTypeId;
            courses.CreateUserId = courseSaveDto.CreateUserId;

            return await _repository.Harta(courses);

        }


    }
}

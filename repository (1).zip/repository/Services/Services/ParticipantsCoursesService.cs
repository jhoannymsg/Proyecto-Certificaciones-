﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Models;
using repository.Interfaces;
using Services.DTO;
using Services.Interfaces;

namespace Services.Services
{
    public class ParticipantsCoursesService : IParticipantsCoursesService
    {
        private readonly IParticipantsCoursesRepository _repository;

        public ParticipantsCoursesService(IParticipantsCoursesRepository repository)
        {
            _repository = repository;
        }

        public async Task<string> Save(ParticipantsCoursesSaveDto participantsCoursesSaveDto)
        {
            ParticipantsCourses participantsCourses = new ParticipantsCourses();

            participantsCourses.ParticipantId = participantsCoursesSaveDto.ParticipantId;
            participantsCourses.CourseId = participantsCoursesSaveDto.CourseId;
            participantsCourses.DateStart = participantsCoursesSaveDto.DateStart;
            participantsCourses.DateEnd = participantsCoursesSaveDto.DateEnd;
            participantsCourses.StatusId = participantsCoursesSaveDto.StatusId;
            participantsCourses.CreateDate = participantsCoursesSaveDto.CreateDate;
            participantsCourses.CreateUserId = participantsCoursesSaveDto.CreateUserId;

            return await _repository.Save(participantsCourses);

        }
    }
}

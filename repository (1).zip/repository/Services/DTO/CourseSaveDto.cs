﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.DTO
{
    public class CourseSaveDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public double Durations { get; set; }

        public int DurationTypeId { get; set; }

        public int StatusId { get; set; }

        public DateTime CreateDate { get; set; }

        public int CreateUserId { get; set; }
    }
}

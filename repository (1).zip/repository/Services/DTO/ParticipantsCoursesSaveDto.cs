﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Services.DTO
{
    public class ParticipantsCoursesSaveDto
    {
        public int ParticipantId { get; set; }
        public int CourseId { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime DateEnd { get; set; }
        public int StatusId { get; set; }
        public DateTime CreateDate { get; set; }
        public int CreateUserId { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Services.DTO;

namespace Services.Interfaces
{
    public interface IParticipantsCoursesService
    {
        Task<string> Save(ParticipantsCoursesSaveDto participantsCoursesSaveDto);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Services.DTO;

namespace Services.Interfaces
{
    public interface ICoursesServices
    {
        Task<List<CoursesDTO>> GetAll();
        Task<string> Harta(CourseSaveDto courseSaveDto);
        Task<CoursesDTO> GetById(int id);
        Task<CoursesDTO> GetByStatus(int status);

        Task<List<CoursesDTO>> GetByIdentify(string identify);
    }
}

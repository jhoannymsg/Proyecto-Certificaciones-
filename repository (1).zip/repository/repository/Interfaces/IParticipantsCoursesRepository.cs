﻿using Domain.Models;

namespace repository.Interfaces
{
    public interface IParticipantsCoursesRepository
    {
        Task<string> Save(ParticipantsCourses participantsCourses);
    }
}

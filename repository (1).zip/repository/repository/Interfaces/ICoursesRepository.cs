﻿using Domain.Models;

namespace repository.Interfaces
{
    public interface ICoursesRepository
    {
        Task<List<Courses>> Getall();
        Task<string> Harta(Courses course);
        Task<Courses> GetById(int id);
        Task<Courses> GetByStatus(int statusId);

        Task<List<Courses>> GetByIdentify(string identify);
    }
}

﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using repository.Interfaces;

namespace repository.Repositories
{
    public class CoursesRepository : ICoursesRepository
    {
        private readonly CourseCertificateContext _context;
        private readonly DbSet<Courses> entities;

        public CoursesRepository(CourseCertificateContext context)
        {
            _context = context;
            entities = _context.Set<Courses>();


        }

        public async Task<List<Courses>> Getall()
        {
            return await entities.ToListAsync();
        }

        public async Task<Courses> GetById(int id)
        {
            return await entities.Where(courses => courses.Id == id).SingleOrDefaultAsync();
        }

        public async Task<List<Courses>> GetByIdentify(string identify)
        {
            return await entities.Include(x => x.ParticipantsCourses)
                                    .ThenInclude(p => p.Participant)
                                .Where(pc => pc.ParticipantsCourses
                                    .Any(p => p.Participant.Identify == identify))
                                .ToListAsync();
        }

        public async Task<Courses> GetByStatus(int statusId)
        {
            return await entities.Where(courses => courses.StatusId == statusId).FirstOrDefaultAsync();
        }

        public async Task<string> Harta(Courses course)
        {
            entities.Add(course);
            await _context.SaveChangesAsync();

            return "Se ha guardado el curso.";
        }
    }
}

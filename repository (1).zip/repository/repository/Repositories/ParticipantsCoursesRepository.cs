﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using repository.Interfaces;

namespace repository.Repositories
{
    public class ParticipantsCoursesRepository : IParticipantsCoursesRepository
    {
        private readonly CourseCertificateContext _context;
        private readonly DbSet<ParticipantsCourses> entities;

        public ParticipantsCoursesRepository(CourseCertificateContext context)
        {
            _context = context;
            entities = _context.Set<ParticipantsCourses>();
        }

        public async Task<string> Save(ParticipantsCourses participantsCourses)
        {
            entities.Add(participantsCourses);
            await _context.SaveChangesAsync();

            return "Se han guardado correctamente.";
        }
    }
}
